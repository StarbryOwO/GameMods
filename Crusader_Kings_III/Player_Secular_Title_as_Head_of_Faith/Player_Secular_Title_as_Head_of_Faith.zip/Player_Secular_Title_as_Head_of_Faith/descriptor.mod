version="1.0.0"
tags={
	"Utilities"
}
name="Player Secular Title as Head of Faith"
author="StarbryOwO"
supported_version="1.19.*"
